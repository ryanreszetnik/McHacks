const AWS = require("aws-sdk");
const Responses = require("../common/Responses");
const Tables = require("../common/Tables");
const accountSid = "ACdb9a6a7a67204df4547a5ba2921b3bfc";
const authToken = "855f522dbb56c1066692e8d9c7ef67f8";
const client = require('twilio')(accountSid, authToken);
var documentClient = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
  const sub = event.requestContext.authorizer.claims.sub;
  const params = {
    Key: { sub: sub },
    TableName: Tables.USERS,
  };
  const resp = (await documentClient.get(params).promise()).Item;


    client.calls
        .create({
            url: 'http://demo.twilio.com/docs/voice.xml',
            to: resp.phone_number,
            from: '+12264076113'
        })
        .then(call => console.log(call.sid));

  return Responses._200(resp);
  
};
