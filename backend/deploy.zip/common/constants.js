const Credentials = {
    accountSid: "ACdb9a6a7a67204df4547a5ba2921b3bfc",
    authToken :"855f522dbb56c1066692e8d9c7ef67f8"
};
  
  module.exports = Credentials;