const Responses = {
  USERS: "doing-great-users",
};

module.exports = Responses;
