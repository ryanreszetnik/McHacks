const Credentials = require("../common/constants");
const client = require('twilio')(Credentials.accountSid, Credentials.authToken);
//const authToken = process.env.TWILIO_AUTH_TOKEN;
//const client = require('twilio')(accountSid, authToken);

client.messages
  .create({
     body: 'This is the ship that made the Kessel Run in fourteen parsecs?',
     from: '+12264076113',
     to: '+16478342344'
   })
  .then(message => console.log(message.sid));